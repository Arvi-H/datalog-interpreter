#include "EOFAutomaton.h"

void EOFAutomaton::S0(const std::string& input) {
    return;
}
